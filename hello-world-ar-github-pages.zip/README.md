# Hello World AR

A GitHub Pages-ready WebXR AR demo for Android.

## What it does
1. Opens an immersive AR camera session.
2. Uses WebXR hit-test to find a real-world surface.
3. Shows a green ring where a surface is detected.
4. Tap the screen to place a white "Hello World" panel.
5. The panel stays at that world position while you move the phone.

## Run it
Upload `index.html` to a GitHub repository and enable GitHub Pages.
Open the resulting HTTPS page on an Android phone in a browser with WebXR/AR support.

Camera access requires HTTPS (GitHub Pages provides this).

## Important
This uses WebXR hit-test, so support depends on the Android phone, browser, and ARCore/WebXR availability. It is not a native APK.
